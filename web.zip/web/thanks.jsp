<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thanks</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <h1>Thanks for joining our list</h1>
    <p>Here is the information that you entered:</p>

    <label>First Name:</label> <span>${user.firstName}</span><br>
    <label>Last Name:</label> <span>${user.lastName}</span><br>
    <label>Email:</label> <span>${user.email}</span><br>
    <label>Date of Birth:</label> <span>${user.dateOfBirth}</span><br>
    <label>How did you hear about us:</label> <span>${user.hearFrom}</span><br>
    <label>Wants updates:</label> <span>${user.wantsUpdates}</span><br>
    <label>Email announcements:</label> <span>${user.emailAnnouncements}</span><br>
    <label>Contact via:</label> <span>${user.contactVia}</span><br>
</body>
</html>